Robotics Business English Mobile Learning Package

Open index.html on your phone. From the home page, open vocabulary_library.html to review the accumulated word bank with parts of speech, examples, and pronunciation.
Keep the entire package together, including learning-assets, english_pronunciation_audio, product_introduction_sync_full.m4a, and both HTML pages.
The grammar coach includes sentence building, answer-specific feedback, transfer practice, and spoken customer dialogues. Translations and detailed explanations are collapsed by default. Playback speed can be reduced to 0.75x.
Practice history is stored in the current browser only. Local-file playback and storage depend on the phone browser. For dependable access by URL, host the complete static site on a web server; a cloud-drive preview is not necessarily a website.

Grammar cards now start folded; click the card heading to expand. All players support pause/resume from the current position, explicit restart, and looping of the current clip. Word buttons also toggle pause/resume; select a word to reveal its player and loop control beneath the vocabulary table. Playing a different clip pauses the previous player without resetting its position.
